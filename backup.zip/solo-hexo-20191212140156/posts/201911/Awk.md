title: Awk
date: '2019-11-19 20:27:26'
updated: '2019-11-19 20:27:58'
tags: [三剑客]
permalink: /articles/2019/11/19/1574166445964.html
---
![](https://img.hacpai.com/bing/20181022.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

# Awk
