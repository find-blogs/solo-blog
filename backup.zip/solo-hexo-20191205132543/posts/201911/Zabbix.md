title: Zabbix
date: '2019-11-19 17:13:05'
updated: '2019-11-19 17:13:05'
tags: [监控]
permalink: /articles/2019/11/19/1574154784948.html
---
![](https://img.hacpai.com/bing/20190425.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# Zabbix

## 官方网址
```
https://www.zabbix.com/
```
