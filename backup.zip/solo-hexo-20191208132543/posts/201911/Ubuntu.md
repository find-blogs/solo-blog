title: 'Ubuntu '
date: '2019-11-19 22:48:31'
updated: '2019-11-19 22:48:31'
tags: [Ubuntu]
permalink: /articles/2019/11/19/1574174911825.html
---
![](https://img.hacpai.com/bing/20171202.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# Ubuntu
