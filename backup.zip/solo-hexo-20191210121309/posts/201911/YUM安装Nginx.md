title: YUM 安装 Nginx
date: '2019-11-19 16:50:23'
updated: '2019-11-21 21:02:07'
tags: [环境搭建]
permalink: /articles/2019/11/19/1574153423582.html
---
![](https://img.hacpai.com/bing/20190414.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# Nginx 安装

## 官方网址
[官方网址](http://nginx.org/)

##  安装软件
```
sudo yum install yum-utils
```
## 增加YUM源
```
cat >>/etc/yum.repos.d/nginx.repo<< EOF
[nginx-stable]
name=nginx stable repo
baseurl=http://nginx.org/packages/centos/$releasever/$basearch/
gpgcheck=1
enabled=1
gpgkey=https://nginx.org/keys/nginx_signing.key
module_hotfixes=true

[nginx-mainline]
name=nginx mainline repo
baseurl=http://nginx.org/packages/mainline/centos/$releasever/$basearch/
gpgcheck=1
enabled=0
gpgkey=https://nginx.org/keys/nginx_signing.key
module_hotfixes=true
EOF
```

```
sudo yum install nginx
```

## 启动Nginx
```
systemctl start nginx
systemctl enable nginx
```
