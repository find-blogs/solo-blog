title: Git
date: '2019-11-19 16:56:25'
updated: '2019-11-19 16:56:25'
tags: [代码管理]
permalink: /articles/2019/11/19/1574153785272.html
---
![](https://img.hacpai.com/bing/20190715.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# Git

## 官方网址
```
https://git-scm.com/
```
