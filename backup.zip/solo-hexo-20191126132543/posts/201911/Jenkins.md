title: Jenkins
date: '2019-11-19 20:24:17'
updated: '2019-11-19 20:26:07'
tags: [Jenkins]
permalink: /articles/2019/11/19/1574166257445.html
---
![](https://img.hacpai.com/bing/20190324.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# Jenkins


