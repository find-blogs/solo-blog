title: Docker 安装
date: '2019-11-19 16:43:34'
updated: '2019-11-21 20:52:19'
tags: [容器]
permalink: /articles/2019/11/19/1574153014498.html
---
![](https://img.hacpai.com/bing/20190424.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# Docker 安装

## 官方网址
[官方网址](https://docs.docker.com/)
## 文档网址
[文档网址](https://docs.docker.com/)


## 卸载旧版本
```
sudo yum remove docker \
                  docker-client \
                  docker-client-latest \
                  docker-common \
                  docker-latest \
                  docker-latest-logrotate \
                  docker-logrotate \
                  docker-engine
```
## 使用存储库安装
```
安装所需的软件包。`yum-utils`提供了`yum-config-manager` 效用，并`device-mapper-persistent-data`和`lvm2`由需要 `devicemapper`存储驱动程序。

$ sudo yum install -y yum-utils \
  device-mapper-persistent-data \
  lvm2

```
```
使用以下命令来设置**稳定的**存储库。

$ sudo yum-config-manager \
    --add-repo \
    https://download.docker.com/linux/centos/docker-ce.repo
```
##  安装DOCKER ENGINE-社区
```
sudo yum install docker-ce docker-ce-cli containerd.io
```
## 启动Docker
```
sudo systemctl start docker
sudo systemctl enable docker
```
